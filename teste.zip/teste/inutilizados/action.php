<!DOCTYPE html>
<html lang="pt-br">
<head>
</head>

<?
            include_once ("header.php");
            include_once ("config.php"); 
      if ($_GET['idpessoa']){ 
              $sql = "SELECT * FROM pessoa WHERE idpessoa = '".$_GET['idpessoa']." ';"; 
                     if ($result = mysqli_query($conn, $sql)){ 
                         if (mysqli_num_rows($result) > 0){ 
                         while ($row = mysqli_fetch_array($result)){ 
                             $_u_pessoa_id = $row['idpessoa']; 
                             $_u_pessoa_nome = $row['nome']; 
                             $_u_pessoa_sexo = $row['sexo']; 
                             echo "</tr>"; 
                        } 
                     } 
                 } 
              }  

?>

        <div class="container">
        <h2 style="text-align: center;">FORMULÁRIO </h2>



            <form action="cb.php?<?=$_SERVER["QUERY_STRING"];?>" method ="POST" name= "update">
            <br/>
            <label> Nome </label><input name="nome" type="text"  value = " <?= @ $_u_pessoa_nome?>">
            <label> Sexo </label><input name="sexo" type="text"  value = " <?= @ $_u_pessoa_sexo?>">
            <button type="submit" name="btnEnviar" class="btn btn-success "> Enviar</button>
            </form>
        </div>
</body>
</html>

