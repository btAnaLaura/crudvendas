<html>
<head>
<meta charset="UTF-8">
    <title>Painel de Controle</title>
<link rel="stylesheet" href="style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>

</head>
<body>
    <?  include_once ("header.php"); ?>
<div class="container">
<div class="row">
    <div class="col-md-12">
         <a class="navbar-brand" href= "form/<?=$_GET['_modulo'];?>.php?<?=$_GET['_modulo'];?>=<?=$_GET['_modulo'];?>&<?=$_GET['acao'];?>=<?=$_GET['acao'];?>">Adicionar Novo Registro </a>
    </div>
</div>
    <? include_once ("config.php"); ?>
</div>
</body>
</html>

