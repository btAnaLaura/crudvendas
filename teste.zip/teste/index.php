<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Painel de Controle</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    <?
    include_once ("header.php");
        if(count($_POST)){ 
            include_once ("cb.php");
        }
            $texto = $_GET['_modulo'];
    ?>
 </head>
    <body>
        <div class="container">
        <?
            if(empty($_GET['_modulo']) and empty($_GET['acao'])){
                echo "<h2>  Escolha uma tabela no menu acima";
            }else{
                  echo( "<h2 style='text-align:center;'>Tabela " . $_GET['_modulo']. ": </h2>
                  <div class='row'><div class='col-md-10'>
                  <a class='navbar-brand'  href='index.php?_modulo=".$_GET['_modulo']."&acao=i'>Novo Registro</a></div>");
            }
        ?>
            <div class="row" >
                    <div class="col-md-10" >
                        <?   if(isset($_GET['acao']) and isset($_GET['_modulo'])){ 
                                  if($_GET['acao'] == 'u'){     
                                 $sql = "SELECT * FROM ".$_GET['_modulo']." WHERE ".$_GET['pk']." = ".$_GET[$_GET['pk']].";";
                                        $result = mysqli_query($conn, $sql);
                                        $row = mysqli_fetch_array($result);    
                                    }
                                        include_once ("form/".$_GET['_modulo'].".php");
                                    }else{
                                        include_once ("pesquisa.php");
                                    }
                        ?>
                    </div>
            </div>
        </div>     
    </body>
</html>