<?  
        foreach($_POST as $key => $value) {    
              $campo .= " " .$key . " = '" . $value."'" ; 
              $campoInsert .= $key;
              $valorInsert .= "'" .$value. "'";
                if ($key === key($_POST)){
                        $campoInsert .= ", ";
                        $valorInsert .= ", ";
                        $campo .= ","  ;
                }
        } 
echo $campo;

if($_GET['_modulo'] and $_GET['acao']){
        if($_GET['acao'] == 'u'){
            $sql = "UPDATE ".$_GET['_modulo']." SET ".$campo." WHERE ".$_GET['pk']." = ".$_GET[$_GET['pk']].";";
             $result = mysqli_query($conn, $sql) ;
                if($result == "ok"){
                        echo  "<script> alert('Registro atualizado com sucesso !'); </script>";
                }else echo  "<script> alert('Erro na atualização do registro, tente mais tarde !'); </script>";
        }elseif ($_GET['acao'] == 'i') {
                $sql = "INSERT INTO ".$_GET['_modulo']." (".$campoInsert. ") VALUES (" .$valorInsert.");";
                $result = mysqli_query($conn, $sql) or die (mysqli_error($conn));
                        if($result == "ok"){
                                echo  ("<script>alert(' Novo registro inserido com sucesso !'); </script>");
                        }
        }else{
                echo "acao invalida";
        }
    } 
  ?> 
            