
<? 
 include_once ("config.php");
 $url = '?'.$_SERVER["QUERY_STRING"];
?>
      <nav class="navbar navbar-expand "  >
      <div class="container-fluid">
          <div class="col" style="margin-left:60px">
          <a class="navbar-brand" href="index.php?_modulo=pessoa&colunas=[idpessoa,nome,sexo]&pk=idpessoa">Pessoa</a>
          <a class="navbar-brand" href="index.php?_modulo=empresa&colunas=[idempresa,nome,status]&pk=idempresa">Empresa</a>
          </div>
      </div>
 </nav>