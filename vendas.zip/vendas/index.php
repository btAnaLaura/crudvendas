<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Painel de Controle</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <?
    include_once ("header.php");
        if(isset($_POST)){ 
            include_once ("cb.php");
        }
            $texto = $_GET['_modulo'];
    ?>
 </head>
    <body>
      <div class="container">
            <?
            if(empty($_GET['_modulo']) and empty($_GET['acao'])){
                echo "<h2>  Escolha uma ação no menu acima";
            }else{
                if($_GET['_modulo'] == 'vendas'){
                    if($_GET['acao'] == 'i'){ 
                         echo ("<div class='row'><div class='col-md-10'>
                          <h2 style='text-align:center;'>Insira os dados da nova venda: </h2>");
                    }
                   if($_GET['acao'] == 'u'){
                    echo ("<div class='row'><div class='col-md-10'>
                    <h2 style='text-align:center;'>Insira os novos dados da venda: </h2>");
                   }
                }if($_GET['_modulo'] == 'produto'){
                    echo ("<div class='row'><div class='col-md-10' style='margin-top:15px; margin-left:25px;'>
                    <a  class='linkproduto'  href='index.php?_modulo=".$_GET['_modulo']."&acao=i'>Inserir novo produto</a></div>");
                }
            }
        ?>
      </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12" style="margin-top:20px;">
                                 <?
                        if(isset($_GET['acao']) and isset($_GET['_modulo'])){
                            if($_GET['acao'] == 'u'){
                              $sql = "SELECT * FROM ".$_GET['_modulo']." WHERE ".$_GET['pk']." = ".$_GET[$_GET['pk']].";";
                                $result = mysqli_query($conn, $sql);
                                   include_once ("form/".$_GET['_modulo'].".php");
                            }if($_GET['acao'] == 'r'){
                                include_once ("pesquisa.php");
                            }if($_GET['acao'] == 'i'){
                                if($_GET['acaovenda'] == 'nova'){
                                    $sql = "SELECT * FROM ".$_GET['_modulo'].";";
                                    $result = mysqli_query($conn, $sql);   
                                }
                                     include_once ("form/".$_GET['_modulo'].".php");
                               }
                    }else{
                            include_once ("pesquisa.php");
                        }
                        ?>
                <? 
                        if($_GET['_modulo'] == 'pessoa' or $_GET['_modulo'] == 'empresa' or $_GET['_modulo'] == 'vendas' and empty($_GET['colunas']) ){
                            include_once ("read/detalhes.php");
                        } 
                        if($_GET['_modulo'] == 'vendaitem' and $_GET['acaovenda'] ==  'atualizar'){
                      
                        }
                
                ?>




                </div>
            </div>
        </div>
    </body>    
</html>