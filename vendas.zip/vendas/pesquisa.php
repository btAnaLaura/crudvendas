<?
if (!empty($_GET['_modulo']) and !empty($_GET['colunas'])){
   //recebe as colunas pela string enviada via get ([campo1,campo2,campo3]) e transformá-las em array, elimninando os colchetes
     $colunas = explode(',',str_replace(']','',str_replace('[','',$_GET['colunas'])));
    $sql = "SELECT * FROM ".$_GET['_modulo'].";";
    if($result = mysqli_query($conn, $sql)){    //aqui faz a consulta na query, com a conexao e comando sql 
            if(mysqli_num_rows($result) > 0){    //aqui checa se o numero de linhas é maior que 0
                echo "<table class='table table-bordered '>";
                echo "<thead >";
                    echo "<tr >";
                    foreach ($colunas as $nomecoluna) {
                      echo '<th style="text-align:center;">'.$nomecoluna.'</th>';
                    }
                    echo '<th style="text-align:center;">Ação</th>';
                    echo "</tr>";
                echo "</thead>";
                echo "<tbody>";
            while($row = mysqli_fetch_array($result)){   //aqui retorna a matriz e passa o ponteiro p frente do resultado, smp com laço de repetição
                echo "<tr id='linha".$row[$_GET['idpk']]."'>";
                foreach ($colunas as $valorcoluna) {
                    echo "<td style='text-align:center;'>" .$row[$valorcoluna] ."</td>";
                
                }
                echo "<td style='text-align:center; margin-left:20px'>";
                ?>
                    <a href="" onclick="deletaRegistro('<?=$_GET['_modulo'];?>','<?=$_GET['pk'];?>',<?=$row[$_GET['pk']];?>)" >Excluir </a>
                    <a href= "?_modulo=<?=$_GET['_modulo'];?>&acao=u&<?=$_GET['pk'];?>=<?=$row[$_GET['pk']];?>&pk=<?=$_GET['pk'];?>" style="margin-left:30px;">  Alterar <a> </td>
                <? 
                echo "</tr>";
              } 
              echo "</tbody>";
              echo "</table>";
        }
    }
}
?>

<script>
        function deletaRegistro(_modulo, pk, idpk)
                {
                    $.ajax(
                    {
                        type: "POST",
                        url: "_ajaxdelete.php?_modulo="+_modulo+"&pk="+pk+"&idpk="+idpk,
                        dataType: "html",
                        success: function(result)
                        {
                            //estudar SELECTOR de jquery
                           if(result == "Ok") {
                               $("#linha"+idpk).hide();                            
                            }
                            else alert("Erro ao excluir registro: "+result);
                        }
                    });
                }
</script>
