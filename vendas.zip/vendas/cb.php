<? 

$prefix = $key = '';
$prefix = $value = '';

 foreach($_POST as $key => $value) {    

    $valores .= $prefix. "'" . $value. "'";
    $chaves .= $prefix. " " . $key. " ";

  $camposUpdate .= $prefix.  " " .$key . " = '" . $value."'" . " " ; 
     $prefix = ' , ';  
        if ($key == 'qtd' ){
            $chaveqtd = $key;
            $valorqtd = $value;
          } if ($key == 'valorunitario' ){
           $chavevalor = $key;
            $valor = $value;
        }
      
}

if($_GET['_modulo'] and $_GET['acao']){
        if($_GET['acaovenda'] == 'nova' and $_GET['acao'] == 'i' and $_GET['idvenda']){
           $tabela = 'vendas';
            $idvenda = "'".$_GET['idvenda']."'";

         echo $sql = "INSERT INTO ".$_GET['_modulo']." ( idvenda, idpessoa, ".$chaves. ", valortotalitem,  criadoem) VALUES (".$idvenda.", ".$idpessoa. ", ".$valores.", ( ".$valorqtd."*".$valor." ) , current_time());";
            $result = mysqli_query($conn, $sql);
            if($result == "ok"){
                echo  "<script> alert('Registro inserido com sucesso !'); </script>";
             }
       

        }  elseif($_GET['acao'] == 'i' ){
         $sql  = "SELECT * FROM ".$_GET['_modulo'].";";
          $sql = "INSERT INTO ".$_GET['_modulo']." (".$chaves. ", criadoem) VALUES (" .$valores.", current_time());";
         $result = mysqli_query($conn, $sql); 
         if($result == "ok"){
            echo  "<script> alert('Registro inserido com sucesso !'); </script>";
         }

            if($_GET['_modulo'] == 'vendas'){
                  $sql  = "SELECT * FROM ".$_GET['_modulo'].";";
                  $sql = "INSERT INTO ".$_GET['_modulo']." (".$chaves. ", datavenda, valor) VALUES (" .$valores.", current_time(), 00.00);";
                  $result = mysqli_query($conn, $sql); 
                     if($result == "ok"){
                        echo  "<script> alert('Registro inserido com sucesso !'); </script>";
                     $last_id =  mysqli_insert_id($conn);
                     }
            } 
            
            
        }elseif($_GET['acaovenda'] == 'atualizar' and $_GET['idvenda'] and $_GET['acao'] == 'u'){
           if($_GET['idvendaitem']){
         echo "<br> update 1:".$sql = "UPDATE ".$_GET['_modulo']." SET ".$camposUpdate.", valortotalitem = ( ".$valorqtd."*".$valor." ), alteradoem = current_time()  WHERE idvendaitem = ". $_GET['idvendaitem'].";";
            $result = mysqli_query($conn, $sql) ;
             if($result == "ok"){
                echo  "<script> alert('Registro atualizado com sucesso !'); </script>";
             }
       }else{
         echo "<br> update 2:".  $sql = "UPDATE ".$_GET['_modulo']." SET ".$camposUpdate." WHERE idvenda = ". $_GET['idvenda'].";";
             $result = mysqli_query($conn, $sql) ;
                if($result == "ok"){
                  echo  "<script> alert('Registro atualizado com sucesso !'); </script>";
              }
           }
        }
    }
?> 



<!-- aqui tenho que fazer o comando de update da tela vendaitens e acao atualizar, a conta tem que ser feita no update -->