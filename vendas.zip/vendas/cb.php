<? 

$prefix = $key = '';
$prefix = $value = '';

 foreach($_POST as $key => $value) {    

    $valores .= $prefix. "'" . $value. "'";
    $chaves .= $prefix. " " . $key. " ";

     $camposUpdate .= $prefix.  " " .$key . " = '" . $value."'" . " " ; 
     $prefix = ' , ';  
        if ($key == 'qtd' ){
            $chaveqtd = $key;
            $valorqtd = $value;
          } if ($key == 'valorunitario' ){
            $chavevalor = $key;
            $valor = $value;
           
        }
}

if($_GET['_modulo'] and $_GET['acao']){
        if($_GET['acaovenda'] == 'nova' and $_GET['acao'] == 'i'){
         echo $sql = "INSERT INTO ".$_GET['_modulo']." ( ".$chaves. ", valortotalitem,  criadoem) VALUES (" .$valores.", ( ".$valorqtd."*".$valor." ) , current_time());";
            $result = mysqli_query($conn, $sql);
            if($result == "ok"){
                echo  "<script> alert('Registro inserido com sucesso !'); </script>";
        }
    
        }elseif($_GET['acao'] == 'i' and $_GET['_modulo'] == 'vendas' ){
           $sql  = "SELECT * FROM ".$_GET['_modulo'].";";
           $sql = "INSERT INTO ".$_GET['_modulo']." (".$chaves. ", criadoem) VALUES (" .$valores.", current_time());";
         $result = mysqli_query($conn, $sql); 
        
          
        }elseif($_GET['acao'] == 'u'){
           $sql = "UPDATE ".$_GET['_modulo']." SET ".$camposUpdate." WHERE ".$_GET['pk']." = ".$_GET[$_GET['pk']].";";
          $result = mysqli_query($conn, $sql) ;
                if($result == "ok"){
                        echo  "<script> alert('Registro atualizado com sucesso !'); </script>";
                }
       }
    }

?> 
