
<div class="row">
    <div class="col-md-12">
         <div class="container">
        <? 
            if ($_GET['acao'] == 'u'){
                $texto = "Alteração do registro no módulo " ;
            }else{
                $texto = "Inserção do novo registro no módulo " ;
            }
        ?>
        <h2><?=$texto .$_GET['_modulo'];?></h2>
         </div>
         <p>Preencha os campos com os dados novos do módulo <?=$_GET['_modulo']?> :</p>
         <form action="index.php<?=$url;?>" method="POST"  enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6">
                    <label>Nome da Empresa: </label>
                    <input type="text" name="nome" class="form-control" value="<?=$row['nome'];?>" maxlength="20" placeholder="Preencha o nome da empresa" required>
                </div>
                <div class="col-md-4">
                <label>Preencha o status da empresa:</label>
                        <select name="status" id="status" style="margin-top:5px; " required>
                           <? $texto = "Escolha a opção: "; ?>
                           <option disabled><?=$texto; ?></option> 
                           <option value="<?=$row['status'];?>">   "   <?=$row['status'];?> " é o valor atual </option>
                           <option value="ativo" >  ativo   </option>
                           <option value="inativo">  inativo   </option>
                        </select>
                </div>
                <div class="col-md-2">
                <input type="submit" class="btn btn-success" value="Salvar" style="margin-top:25px;">
                </div>
            </div>
                <div class="row">
                    <div class="col-md-10" style="margin-top:20px;">
                      <label id="idpessoa">Selecione o funcionário: </label>
                        <?
                        $tabela = 'pessoa';
                        $sql = "SELECT * FROM ".$tabela.";";
                        $result = mysqli_query($conn, $sql);
                        
                        ?>
                    <select name="pessoa" id="idpessoa" style="margin-top:5px; margin-left:10px;" required>
                            <? $texto = "Escolha a opção: "; 
                                while($rowCliente = mysqli_fetch_array($result)){
                                    echo  ('<option value='.$rowCliente["nome"].' > ID Funcionário:  '.$rowCliente["idpessoa"].'   -    Nome:  '.$rowCliente["nome"].'   </option>');
                                }
                            ?>
                     </select>
                    </div>
                </div>
         </form>
     </div>
</div>        