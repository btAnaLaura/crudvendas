<form action="index.php<?=$url;?>" method="POST"  enctype="multipart/form-data">
            <div class="row">           
                <div class="col-md-6">
                <label id="idpessoa">Selecione o funcionário: </label>
                        <?
                        $tabela = 'pessoa';
                        $sql = "SELECT * FROM ".$tabela.";";
                        $result = mysqli_query($conn, $sql);                   

                        ?>
                    <select name="pessoa" id="idpessoa" style="margin-top:5px; margin-left:10px;" required>
                            <? $texto = "Escolha a opção: "; 
                                while($rowCliente = mysqli_fetch_array($result)){
                                    echo  ('<option value='.$rowCliente["idpessoa"].' > Nome:  '.$rowCliente["nome"].'   </option>');
                                }
                            ?>
                     </select>
                </div>
                 </div>

        <div id="newRow"></div>
               
   </form>
        
    </div> 

            <form action="?_modulo=vendaitem&acao=i&acaovenda=nova" method="POST" enctype="multipart/form-data"  >
                      
                   <div id= "inputformRow" class="row" style="margin-top: 20px" >
                        <div class="col-md-9"> 
                             <label for="produto">Escolha o novo produto</label> 
                             <?      $tabela = 'produto';
                                        $sql = "SELECT * FROM ".$tabela.";";
                                        $result = mysqli_query($conn, $sql); 
                                    ?> 
                          <select name="idproduto" id="idproduto" class="produto" onchange="idprodutochange(this.value)"  style="margin-top:5px; margin-left:10px;" required>
                            <? while($row = mysqli_fetch_array($result)){
                                        echo  (' <option value='.$row["idproduto"].'> Nome Produto:  '.$row["nome"].'</option>');  };
                            ?> 
                           </select> 
                           <input type="text" id="valorunitario" name="valorunitario" value="" readonly size="3">
                           <input type="text" id="qtd" name="qtd" onkeyup = "qtd(this.value)" size="3">
                        </div>
                        <div class="col-md-1" style="margin-top: 25px; margin-right: 25px" >
                        <input type="submit" class="btn btn-info" id="addRow" value="Adicionar" style="margin-left: 20px;">
                          <div class="input-group-append">   </div>     
                        </div>
                        <div class="col-md-1" style="margin-top: 25px">
                          <button id="removeRow" type="button" class="btn btn-danger">Remover</button>
                        </div>
                     </div>
               </form>

                       <div class="row">    
                             <input type="submit" class="btn btn-success" value="Salvar" style="margin-top:25px;">
                       </div>
  

   <script>


    function idprodutochange(idproduto, valorunitario){
        $.ajax({
            type: 'post',
            url: "consultapreco.php?idproduto="+idproduto,
            dataType: "html",
            success: function(result){
                valorunitario = result;
                document.querySelector("#valorunitario").value = valorunitario;
            }
        });
    }

    function quantidade(qtd){
         document.getElementById("#qtd").value = qtd;

    }
</script>

                