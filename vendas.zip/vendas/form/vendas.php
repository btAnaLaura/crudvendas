<form action="index.php<?=$url;?>" method="POST"  enctype="multipart/form-data"> 
<div class="container">
     <label><h4>ID da Venda: </h4></label>
    <input type="text" style="text-align: center; margin:20px;"; 
            <? if ($_GET['acao'] == 'i'){
                ?>value="<?=$last_id;?>"<?
            }elseif ($_GET['acao'] == 'u'){
                ?>value="<?=$_GET['idvenda'];?>"<?
            } ?> size="3" >

<?
    if($_GET['_modulo'] =='vendas' and $_GET['acao'] == 'i'){
        ?>
                <div class="row">          
                <div class="col-md-6" style="text-align: center;">
                <label id="idpessoa">Selecione o funcionário: </label>
                        <?
                        $tabela = 'pessoa';
                        $sql = "SELECT * FROM ".$tabela.";";
                        $result = mysqli_query($conn, $sql);                   
                        ?>
                    <select name="idpessoa" id="idpessoa" style="margin-top:5px; margin-left:10px;" required>
                            <? $texto = "Escolha a opção: "; 
                                while($rowCliente = mysqli_fetch_array($result)){
                                    echo  ('<option value='.$rowCliente["idpessoa"].' > Nome:  '.$rowCliente["nome"].'   </option>');
                                }
                            ?>
                     </select>
                </div> 
             
                <div class="col-md-6" style="text-align: center;">  
                     <label id="idempresa">Selecione a empresa: </label>
                        <?
                        $tabela = 'empresa';
                        $sql = "SELECT * FROM ".$tabela.";";
                        $result = mysqli_query($conn, $sql);   
                        ?>
                    <select name="idempresa" id="idempresa" style="margin-top:5px; margin-left:10px;" required>
                            <? $texto = "Escolha a opção: "; 
                                while($rowEmpresa = mysqli_fetch_array($result)){
                                    echo  ('<option value='.$rowEmpresa["idempresa"].' > Nome:  '.$rowEmpresa["nome"].'   </option>');
                                }
                            ?>
                     </select>
                </div>
   </form>
<div class="container">
 <? if( !empty($last_id) and $_GET['acao'] == 'i'){
    ?>
<form action="?_modulo=vendaitem&acao=i&acaovenda=nova&idvenda=<?=$last_id?>&idpessoa=<?=$_POST['idpessoa'];?>&pk=idpessoa" method="POST"  enctype="multipart/form-data">
        <?
           $tabela = 'vendas';
           $sql = "SELECT * FROM ".$tabela.";";
           $result = mysqli_query($conn, $sql); 
        ?>
            <div class="row">
                <div class="col-md-6" style="text-align: right; margin-top:25px; margin-bottom:25px;">
                 <input type="submit" class="btn btn-info" value="Inserir Produtos" style="margin-top:25px;">
                </div>    
            </div>
        </div>
</form>         
    
<? } else {  ?>  

    <div class="row">
        <div class="col-md-6" style="text-align: right; margin-top:25px; margin-bottom:25px;">
           <input type="submit" class="btn btn-success" value="Iniciar Venda" style="margin-top:25px; "> 
        </div>
    </div>  
 </div>   <?} ?>
</div>     
</div>
<? } ?>
    
  <? 
        if($_GET['acao'] == 'u'){
            
          $sql = "SELECT * FROM ".$_GET['_modulo']." WHERE idvenda=".$_GET['idvenda'].";";
          $result = mysqli_query($conn, $sql); 
          $row = mysqli_fetch_array($result);
          $idpessoa = $row['idpessoa'];
          $idempresa = $row['idempresa'];
  ?>
        <div class="row">
            <div class="col-md-4">
                <label for="funcionario"> Funcionário cadastrado:</label> 
                <? 
                    $tabela = 'pessoa';
                    $sql = "SELECT * FROM ".$tabela." WHERE idpessoa=".$idpessoa.";";
                    $result = mysqli_query($conn, $sql);   
                    $row = mysqli_fetch_array($result);
                    $nomepessoa = $row['nome'];
                ?>   
                <input type="text" name="idpessoa" id="idpessoa" value=" <?=$idpessoa?> " readonly>        
            </div>
    
            <div class="col-md-4">
                <label for="empresa"> Empresa cadastrada:</label> 
                <? 
                    $tabela = 'empresa';
                    $sql = "SELECT * FROM ".$tabela." WHERE idempresa=".$idempresa.";";
                    $result = mysqli_query($conn, $sql);   
                    $row = mysqli_fetch_array($result);
                    $nomeempresa = $row['nome'];
                ?>   
                <input type="text" name="idempresa" id="idempresa" value="<?=$idempresa;?>" readonly>        
            </div>
        </div> 


        <?
                        //aqui tem que ser o comando que vai mostrar a tabela entao
                 $sql = "SELECT * FROM ".$_GET['_modulo']." WHERE idvenda= ".$_GET['idvenda'].";";
                  $result = mysqli_query($conn, $sql);    //aqui faz a consulta na query, com a conexao e comando sql
                  if(mysqli_num_rows($result) > 0){   
                      echo "<table class='table table-bordered '>";
                    echo "<thead >";
                        echo "<tr >";
                    echo '<th style="text-align:center;">Id Venda </th>';
                    echo '<th style="text-align:center;">Valor </th>';     
                    echo '<th style="text-align:center;">Quantidade </th>';   
                    echo '<th style="text-align:center;">Valor Total Item</th>';
                    echo '<th style="text-align:center;">Data da Venda</th>';
                    echo '<th style="text-align:center;">Ação</th>';
                    echo '</thead>';
                    echo '</tr>';
                    while($row = mysqli_fetch_array($result)){
                   
            //aqui retorna a matriz e passa o ponteiro p frente do resultado, smp com laço de repetição
                    
                          echo "<td style='text-align:center;'>" .$row['idvenda']."</td>";
                          echo "<td style='text-align:center;'>" .$_POST['valor']."</td>";
                          echo "<td style='text-align:center;'>" .$row['idpessoa']."</td>";
                          echo "<td style='text-align:center;'>" .$row['idempresa']."</td>";
                          echo "<td style='text-align:center;'>" .$row['datavenda']."</td>";
                          echo "<td style='text-align:center;'>";
                          echo "<a class='link' href='?_modulo=vendaitem&acao=u&acaovenda=atualizar&idvenda=".$_GET['idvenda']."&pk=idvenda' title='Editar Registro' data-toggle='tooltip'><span class='glyphicon glyphicon-pencil'></span></a>";
                      echo "</td>";
                          echo "</tr>";
                          
            }
                echo "</tbody>";
                echo "</table>";
            }

            ?>


<form action="index.php?_modulo=vendas&acao=u&idvenda=<?=$_GET['idvenda'];?>&pk=idvenda" method="post">
           
        <div class="row">
                <div class="col-md-12">
                    <label for="total">Total da compra</label>
                    <input type="text" style="text-align:center; margin-left:10px;" id="valor" name="valor" value="<?=$_POST['valor']?>">
                </div>
            </div>
    </div>
  
      <div class="row" >
      <div class="col-md-12" style="margin-top:25px; text-align: right;">
        <input type="submit"   class="btn btn-danger" value="Salvar venda " >
      </div>    
        </div>
  </form>


<?}?>