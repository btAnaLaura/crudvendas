<div class="container">
    <label for="texto"> Informações do produto adicionado a lista: </label>
 <? echo $sql = "SELECT * FROM " .$_GET['_modulo']. ";"?> 
    <div class="row">
        <div class="col">
         <? if($_POST['idproduto']){  
         $tabela = 'produto';
            $sql = "SELECT * FROM ".$tabela." WHERE idproduto= ".$_POST['idproduto'].";";
           $result = mysqli_query($conn, $sql);
          $row = mysqli_fetch_array($result); 
          
        
        }?>
        </div>
    </div>

</div>