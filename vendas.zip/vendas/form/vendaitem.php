<!-- adicionar aqui condição p insert e update -->

<div class="container">

<form action="index.php<?= $url;?>" method="post">
<? 
    if($_GET['acao'] == 'i'){
?>


  <label for="texto">Escolha seus produtos abaixo</label>
  <div class="row">
                <div class="col-md-5">  
                <label id="idproduto">Selecione o produto: </label>
                        <?
                        $tabela = 'produto';
                        $sql = "SELECT * FROM ".$tabela.";";
                        $result = mysqli_query($conn, $sql);               
                        ?>
                    <select name="idproduto" id="idproduto" style="margin-top:5px; margin-left:10px;"  onchange="idprodutochange(this.value)" required>
                            <?  
                                while($rowProduto = mysqli_fetch_array($result)){
                                    echo  ('<option value='.$rowProduto["idproduto"].' > Nome:  '.$rowProduto["nome"].'   </option>');
                                }
                            ?>
                     </select>
                </div>
          <div class="col-md-3" style="margin-right:10px;">
              <label for="preco"> Veja o preço unitário:</label>
              <input type="text" id="valorunitario" name="valorunitario" value="" readonly size="3">
          </div>
          <div class="col">
              <label for="quantidade"> Selecione a quantidade:</label>
              <input type="text" id="qtd" name="qtd" onkeyup = "quantidade(this.value)" size="3">
          </div>
        <?
            if(empty($_GET['idpessoa'])){
        ?>
     <div class="row">          
                <div class="col-md-6" style="text-align: center;">
                <label id="idpessoa">Selecione o funcionário: </label>
                        <?
                        $tabela = 'pessoa';
                        $sql = "SELECT * FROM ".$tabela.";";
                        $result = mysqli_query($conn, $sql);                   
                        ?>
                    <select name="idpessoa" id="idpessoa" style="margin-top:5px; margin-left:10px;" required>
                            <? $texto = "Escolha a opção: "; 
                                while($rowCliente = mysqli_fetch_array($result)){
                                    echo  ('<option value='.$rowCliente["idpessoa"].' > Nome:  '.$rowCliente["nome"].'   </option>');
                                }
                            ?>
                     </select>
                </div> 
             
           <? } ?>
            
           




    </div>
    <div class="row" >    
                <input type="submit" class="btn btn-primary" value="Salvar Produto" style="margin-top:25px;">
                 </div>
</form>
            <?
            //aqui tem que ser o comando que vai somar o total das compras e jogar no value input.

            if($_GET['acao'] == 'i'){
                $sql = "SELECT * from ".$_GET['_modulo']." WHERE idvenda= ".$_GET['idvenda'].";";
                    $result = mysqli_query($conn, $sql); 
                    while($rowCliente = mysqli_fetch_assoc($result)){
                        $somatotal += $rowCliente['valortotalitem'];
                    }   
            }
              
            ?> 
            <?
                        //aqui tem que ser o comando que vai mostrar a tabela entao
              if($_GET['acaovenda'] == 'nova' and isset($_GET['idvenda'])){
                 $sql = "SELECT * FROM ".$_GET['_modulo']." WHERE idvenda= ".$_GET['idvenda'].";";
                  $result = mysqli_query($conn, $sql);    //aqui faz a consulta na query, com a conexao e comando sql
                  if(mysqli_num_rows($result) > 0){   
                      echo "<table class='table table-bordered '>";
                    echo "<thead >";
                        echo "<tr >";
                    echo '<th style="text-align:center;">IdProduto </th>';
                    echo '<th style="text-align:center;">Valor Unitário </th>';     
                    echo '<th style="text-align:center;">Quantidade </th>';   
                    echo '<th style="text-align:center;">Valor Total Item</th>';
                    echo '<th style="text-align:center;">Criado Em</th>';
                    echo '</thead>';
                    echo '</tr>';
                    while($row = mysqli_fetch_array($result)){
                   
        // aqui como era uma consulta "personalizada" eu utilizei cada campo c o valor do array correspondente
        
                    
                          echo "<td style='text-align:center;'>" .$row['idproduto']."</td>";
                          echo "<td style='text-align:center;'>" .$row['valorunitario']."</td>";
                          echo "<td style='text-align:center;'>" .$row['qtd']."</td>";
                          echo "<td style='text-align:center;'>" .$row['valortotalitem']."</td>";
                          echo "<td style='text-align:center;'>" .$row['criadoem']."</td>";
                          echo "</tr>";
            }
                echo "</tbody>";
                echo "</table>";
            }
        }
            ?>
        <form action="index.php?_modulo=vendas&acao=u&idvenda=<?=$_GET['idvenda'];?>&pk=idvenda" method="post">
            <div class="row">
                <div class="col-md-12">
                    <label for="total">Total da compra</label>
                    <input type="text" style="text-align:center; margin-left:10px;" id="valor" name="valor" value="<?=$somatotal?>">
                </div>
            </div>
    </div>
  
      <div class="row" >
      <div class="col-md-12" style="margin-top:25px; text-align: right;">
        <input type="submit"   class="btn btn-danger" value="Salvar venda " >
      </div>    
    </div>
  </form>
 <?} ?> 







  <!-- ******************************************* DIVISÃO DE CÓDIGOS AQUI ************************************ -->

  
  <? if ($_GET['acao'] == 'u' and $_GET['acaovenda'] == 'atualizar' ){?>
                        <? if ($_GET['idproduto']){?>  <?
                            $tabela = 'produto';
                            $sql = "SELECT * FROM ".$tabela." WHERE idproduto = ".$_GET['idproduto'].";";
                            $result = mysqli_query($conn, $sql); 
                            while($rowProduto = mysqli_fetch_array($result)){
                            $nomeproduto = $rowProduto['nome'];
                            $valorproduto = $rowProduto['valor'];
                            }
                            if ($_POST['valorunitario'] and $_POST['qtd']){
                                $valorunitario = $_POST['valorunitario'] ;
                                $qtd = $_POST['qtd'];
                            }
                            ?>
       <? }?>
<div class="row">
<div class="col-md-5">  
    <label id="idproduto">ID do produto selecionado: </label>
    <input type="text" style="text-align:center;" size = "2" readonly value="<?=$_GET['idproduto'];?>">
    <input type="text" style="text-align:center;" readonly value="<?=$nomeproduto?>">
</div>
<form action="index.php<?= $url;?>" method="POST">
 
    <div class="col-md-3" style="margin-right:10px;">
         <label for="preco"> Veja o preço unitário:</label>
        <input type="text" id="valorunitario" name="valorunitario" value="<?=$valorproduto?>" readonly size="3">
    </div>
        <div class="col">
            <label for="quantidade"> Selecione a quantidade:</label>
            <input type="text" id="qtd" name="qtd" value=" " onkeyup = "quantidade(this.value)" size="3">
        </div>
    </div>
        <div class="row" > 
            <div class="col-md-5">
             <input type="submit" class="btn btn-primary" value="Salvar Produto" style="margin-top:25px;"> 
            </div>   
    
        </div>
</form>    
   
       </div>
              
        <? 
            if(empty($_GET['idproduto'])){
                echo ('<label style="margin-top:20px;"> SELECIONE UM PRODUTO PARA EDITAR: </label>');
            }  ?>
       <br> <label style="margin-top:20px;" for="texto">Veja abaixo as informações da sua venda e quais campos estão disponíveis para atualização: </label>
            <h6>Campos com ( * ) serão alterados</h6>
<?
                  //aqui tem que ser o comando que vai mostrar a tabela entao
                 $sql = "SELECT * FROM ".$_GET['_modulo']." WHERE idvenda= ".$_GET['idvenda'].";";
                  $result = mysqli_query($conn, $sql);    //aqui faz a consulta na query, com a conexao e comando sql
                  if(mysqli_num_rows($result) > 0){   
                      echo "<table class='table table-bordered '>";
                    echo "<thead >";
                        echo "<tr >";
                    echo '<th style="text-align:center;">ID Venda Item </th>';
                    echo '<th style="text-align:center;">ID Venda </th>';     
                    echo '<th style="text-align:center;">ID Produto </th>'; 
                    echo '<th style="text-align:center;">ID Pessoa </th>';  
                    echo '<th style="text-align:center;">Valor Unitário* </th>';
                    echo '<th style="text-align:center;">Quantidade* </th>';
                    echo '<th style="text-align:center;">Valor Total Item* </th>';
                    echo '<th style="text-align:center;">Criado Em</th>';
                    echo '<th style="text-align:center;">Alterado Em* </th>';
                    echo '<th style="text-align:center;">Editar</th>';
                    echo '</thead>';
                    echo '</tr>';
                    while($row = mysqli_fetch_array($result)){
            //aqui retorna a matriz e passa o ponteiro p frente do resultado, smp com laço de repetição       
                          echo "<td style='text-align:center;'>" .$row['idvendaitem']."</td>";
                          echo "<td style='text-align:center;'>" .$row['idvenda']."</td>";
                          echo "<td style='text-align:center;'>" .$row['idproduto']."</td>";
                          echo "<td style='text-align:center;'>" .$row['idpessoa']."</td>";
                          echo "<td style='text-align:center;'>" .$row['valorunitario']."</td>";
                          echo "<td style='text-align:center;'>" .$row['qtd']."</td>";
                          echo "<td style='text-align:center;'>" .$row['valortotalitem']."</td>";
                          echo "<td style='text-align:center;'>" .$row['criadoem']."</td>";
                          echo "<td style='text-align:center;'>" .$row['alteradoem']."</td>";
                          echo "<td style='text-align:center;'>";
                          echo "<a class='link' href='?_modulo=vendaitem&acao=u&acaovenda=atualizar&idvenda=".$_GET['idvenda']."&pk=idvenda&idproduto=".$row['idproduto']."&idvendaitem=".$row['idvendaitem']."' title='Editar Registro' data-toggle='tooltip'><span class='glyphicon glyphicon-pencil'></span></a>";
                          echo "</td>";
                          echo "</tr>";
                          $somatotal += $row['valortotalitem'];
            }
                echo "</tbody>";
                echo "</table>";
            }  
   ?> 
         
<form action="?_modulo=vendas&acao=u&acaovenda=atualizar&idvenda=<?=$_GET['idvenda']?>" method="post">
<div class="row">
                <div class="col-md-12">
                    <label for="total">Total da compra</label>
                    <input type="text" style="text-align:center; margin-left:10px;" id="valor" name="valor" value="<?=$somatotal?>">
                </div>
            </div>
  <div class="col-md-12" style="margin-top:25px; text-align: right;">
        <input type="submit"   class="btn btn-danger" value="Salvar venda " >
      </div>    
</form>
    
    <div class="col-md-12" style="text-align:right; margin-bottom:25px;">
         <form action="?_modulo=vendaitem&acao=i&acaovenda=nova&idvenda=<?=$_GET['idvenda']?>" method="POST"  enctype="multipart/form-data">
             <input type="submit" class="btn btn-success" value="Adicionar Novo Produto" style="margin-top:25px;">
      </form>
    </div>

    
   <? }  ?>    
   

  <script>
function idprodutochange(idproduto, valorunitario){
        $.ajax({
            type: 'post',
            url: "consultapreco.php?idproduto="+idproduto,
            dataType: "html",
            success: function(result){
                valorunitario = result;
                document.querySelector("#valorunitario").value = valorunitario;
            }
        });
    }
    function quantidade(qtd){
         document.getElementById("#qtd").value = qtd;
    }
</script>
