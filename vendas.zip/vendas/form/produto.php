<div class="row">
    <div class="col-md-12">
        <div class="container">
        <? 
            if ($_GET['acao'] == 'u'){
                $texto = "Alteração do produto" ;
            }else{
                $texto = "Inserção do novo produto" ;
            }
        ?>
         <p>Preencha os campos com os dados novos do produto :</p>
         <form action="index.php<?=$url;?>" method="POST"  enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-4">
                    <label>Nome do produto: </label>
                    <input type="text" name="nome" class="form-control" value="<?=$row['nome'];?>" maxlength="20" placeholder="Preencha o nome do produto" required>
                </div>
                <div class="col-md-4">
                <label>Valor do produto: </label>
                    <input type="text" name="valor" class="form-control" value="<?=$row['valor'];?>" maxlength="20" placeholder="Preencha o valor do produto R$0.00" required>
                </div>
                <div class="col-md-4">
                <label id="idpessoa">Selecione o funcionário: </label>
                <?
                  $tabela = 'empresa';
                   $sql = "SELECT * FROM ".$tabela.";";
                  $result = mysqli_query($conn, $sql);
                  
                 ?>
                  <select name="idempresa" id="idempresa" style="margin-top:5px; margin-left:10px; " required>
                           <? $texto = "Escolha a opção: "; 
                           while($rowEmpresa = mysqli_fetch_array($result)){
                   echo  ('<option value='.$rowEmpresa["idempresa"].' > ID Empresa:  '.$rowEmpresa["idempresa"].'   -    Nome:  '.$rowEmpresa["nome"].'   </option>');
                  }?>
                        </select>
                </div>
                <div class="col-md-12" style="text-align: right; ">
                <input type="submit" class="btn btn-success" value="Salvar" style="margin-top:25px;">
                </div>
         </form>
        </div>
    </div>
</div>