<?
include_once ("config.php");
 $url = '?'.$_SERVER["QUERY_STRING"];
?>


      <nav class="navbar navbar-expand" style = "background-color: #204144;" > 
      <div class="container-fluid">
          <div class="col" style="margin-left:60px">
          <a class="navbar-brand" href="index.php?_modulo=produto&colunas=[idproduto,nome,valor,idempresa]&pk=idproduto"><span class="fa fa-list-ul"></span><span class="link"> Lista de Produtos</a>
          <a class="navbar-brand" href="index.php?_modulo=vendas&acao=i"><span class="fa fa-cart-arrow-down"></span><span class="link">  Venda</a>
          <a class="navbar-brand" href="index.php?_modulo=vendas&colunas=[idvenda,valor,idempresa,idpessoa,datavenda]&pk=idvenda"><span class="fa fa-tasks"></span><span class="link">  Vendas Realizadas</a>
          <a class="navbar-brand" href="index.php?_modulo=empresa&colunas=[idempresa,nome,status]&pk=idempresa"><span class="fa fa-building"></span><span class="link">  Empresa</a>
          <a class="navbar-brand" href="index.php?_modulo=pessoa&colunas=[idpessoa,nome,sexo]&pk=idpessoa"><span class="fa fa-users"></span><span class="link">  Pessoas</a>

          </div>
      </div>
 </nav>
 
