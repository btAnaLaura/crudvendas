<?
include_once ("config.php");
 $url = '?'.$_SERVER["QUERY_STRING"];
?>
      <nav class="navbar navbar-expand "  >
      <div class="container-fluid">
          <div class="col" style="margin-left:60px">
          <a class="navbar-brand" href="index.php?_modulo=produto&colunas=[idproduto,nome,valor,idempresa]&pk=idproduto">Lista de Produtos</a>
          <a class="navbar-brand" href="index.php?_modulo=vendas&acao=i">Venda</a>
          <a class="navbar-brand" href="index.php?_modulo=vendas&acao=r&colunas=[idvenda,valor,idempresa,idpessoa,datavenda]&pk=idvenda">Vendas Realizadas</a>
          </div>
      </div>
 </nav>