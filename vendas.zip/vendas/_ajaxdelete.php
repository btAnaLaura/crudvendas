<?
if(!empty($_GET['_modulo']) and !empty($_GET['pk']) and !empty($_GET['idpk'])){
    //Instancia conexão
   include_once ("config.php");
   $sql = "DELETE FROM ".$_GET['_modulo']." WHERE ".$_GET['pk']." = ".$_GET['idpk'].";";
  $result = mysqli_query($conn, $sql);
}
?>

