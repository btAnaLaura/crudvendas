<!-- aqui vai ser o select de todos os modulos para mostrar os detalhes E NÃO EDITÁVEIS
POR MÓDULOS:
 - empresa: vai mostrar o nome dos funcionários com o mesmo idempresa, e quais id de compra eles fizeram e se nao tiver mostrar uma mensagem que nao tem venda 
 cadastrada no id da empresa
 - pessoas: vai mostrar os detalhes tipo nome, empresa q é cadastrada, e um resumo das compras que fez. e se nao tiver mostrar q n fez compra  -->

 <div class="container">
    
  <? 
        if($_GET['_modulo'] == 'pessoa' and $_GET['pk']){ 
            ?><h3 style="margin-bottom: 35px; text-align: center;"> Detalhes do módulo <?=$_GET['_modulo'];?>: </h3>
        <?  
          $idpessoa = $_GET[$_GET['pk']];
          $sql= "SELECT * FROM ".$_GET['_modulo']." WHERE idpessoa=".$idpessoa.";";
          $resultado = mysqli_query($conn, $sql);
         
          if(mysqli_num_rows($resultado) > 0){   
              echo "<table class='table table-bordered '>";
            echo "<thead >";
                echo "<tr >";
            echo '<th style="text-align:center;">Id Empresa </th>';
            echo '<th style="text-align:center;">Nome </th>';     
            echo '<th style="text-align:center;">Sexo </th>';   
            echo '<th style="text-align:center;">Id Empresa</th>';
            echo '<th style="text-align:center;">Criado Em</th>';
            echo '</thead>';
            echo '</tr>';
            while($rowPessoa = mysqli_fetch_array($resultado)){
                  echo "<td style='text-align:center;'>" .$idpessoa."</td>";
                  echo "<td style='text-align:center;'>" .$rowPessoa['nome']."</td>";
                  echo "<td style='text-align:center;'>" .$rowPessoa['sexo']."</td>";
                  echo "<td style='text-align:center;'>" .$rowPessoa['idempresa']."</td>";
                  echo "<td style='text-align:center;'>" .$rowPessoa['criadoem']."</td>";
                  echo "</tr>";
    }
        echo "</tbody>";
        echo "</table>";
}
 
 
  } if($_GET['_modulo'] == 'empresa' and $_GET['pk']){
    ?><h3 style="margin-bottom: 35px; text-align: center;"> Detalhes do módulo <?=$_GET['_modulo'];?>: </h3>
    <?
            $idempresa = $_GET[$_GET['pk']];
             $sql= "SELECT * FROM ".$_GET['_modulo']." WHERE idempresa=".$idempresa.";";
            $result = mysqli_query($conn, $sql);
            if(mysqli_num_rows($result) > 0){   
                echo "<table class='table table-bordered '>";
              echo "<thead >";
                  echo "<tr >";
              echo '<th style="text-align:center;">Id Empresa </th>';
              echo '<th style="text-align:center;">Nome </th>';     
              echo '<th style="text-align:center;">Status </th>';   
              echo '<th style="text-align:center;">Id Pessoa</th>';
              echo '<th style="text-align:center;">Criado Em</th>';
              echo '</thead>';
              echo '</tr>';
              while($row = mysqli_fetch_array($result)){
                    echo "<td style='text-align:center;'>" .$idempresa."</td>";
                    echo "<td style='text-align:center;'>" .$row['nome']."</td>";
                    echo "<td style='text-align:center;'>" .$row['status']."</td>";
                    echo "<td style='text-align:center;'>" .$row['idpessoa']."</td>";
                    echo "<td style='text-align:center;'>" .$row['criadoem']."</td>";
                    echo "</tr>";
      }
          echo "</tbody>";
          echo "</table>";
      }
 
   }if($_GET['_modulo'] == 'vendas' and $_GET['pk'] and empty($_GET['acao'])){
    ?><h3 style="margin-bottom: 35px; text-align: center;"> Detalhes do módulo <?=$_GET['_modulo'];?>: </h3>
    <?
            $idvenda = $_GET[$_GET['pk']];
            $sql= "SELECT * FROM ".$_GET['_modulo']." WHERE idvenda=".$idvenda.";";
            $result = mysqli_query($conn, $sql);
            if(mysqli_num_rows($result) > 0){   
                echo "<table class='table table-bordered '>";
              echo "<thead >";
                  echo "<tr >";
              echo '<th style="text-align:center;">Id Venda </th>';
              echo '<th style="text-align:center;">Valor </th>';     
              echo '<th style="text-align:center;">Id Empresa</th>';   
              echo '<th style="text-align:center;">Id Pessoa</th>';
              echo '<th style="text-align:center;">Data da Venda</th>';
              echo '</thead>';
              echo '</tr>';
              while($row = mysqli_fetch_array($result)){
                    echo "<td style='text-align:center;'>" .$idvenda."</td>";
                    echo "<td style='text-align:center;'>" .$row['valor']."</td>";
                    echo "<td style='text-align:center;'>" .$row['idempresa']."</td>";
                    echo "<td style='text-align:center;'>" .$row['idpessoa']."</td>";
                    echo "<td style='text-align:center;'>" .$row['datavenda']."</td>";
                    echo "</tr>";
      }
          echo "</tbody>";
          echo "</table>";
      }

     ?> <h4>Itens da venda:</h4>
         <?
         
         $tabela = 'vendaitem';
         $sql = "SELECT * FROM ".$tabela." WHERE idvenda= ".$_GET['idvenda'].";";
                  $result = mysqli_query($conn, $sql);    //aqui faz a consulta na query, com a conexao e comando sql
                  if(mysqli_num_rows($result) > 0){   
                      echo "<table class='table table-bordered '>";
                    echo "<thead >";
                        echo "<tr >";
                    echo '<th style="text-align:center;">IdProduto </th>';
                    echo '<th style="text-align:center;">Valor Unitário </th>';     
                    echo '<th style="text-align:center;">Quantidade </th>';   
                    echo '<th style="text-align:center;">Valor Total Item</th>';
                    echo '<th style="text-align:center;">Criado Em</th>';
                    echo '</thead>';
                    echo '</tr>';
                    while($row = mysqli_fetch_array($result)){
                   
        // aqui como era uma consulta "personalizada" eu utilizei cada campo c o valor do array correspondente
        
                    
                          echo "<td style='text-align:center;'>" .$row['idproduto']."</td>";
                          echo "<td style='text-align:center;'>" .$row['valorunitario']."</td>";
                          echo "<td style='text-align:center;'>" .$row['qtd']."</td>";
                          echo "<td style='text-align:center;'>" .$row['valortotalitem']."</td>";
                          echo "<td style='text-align:center;'>" .$row['criadoem']."</td>";
                          echo "</tr>";
            }
                echo "</tbody>";
                echo "</table>";
            }
        }
  ?>
 
 
 
 
 
 
 
 
 
 
 
 
 </div>