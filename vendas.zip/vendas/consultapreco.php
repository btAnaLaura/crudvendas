<?       require_once ("config.php");
        if($_GET['idproduto']){  
         $tabela = 'produto';
            $sql = "SELECT * FROM ".$tabela." WHERE idproduto= ".$_GET['idproduto'].";";
           $result = mysqli_query($conn, $sql);
         $row = mysqli_fetch_array($result); 
        echo $valor = $row['valor'] ;   
           
        }

?>